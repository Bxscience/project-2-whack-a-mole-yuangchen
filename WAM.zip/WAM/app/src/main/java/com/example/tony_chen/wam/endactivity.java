package com.example.tony_chen.wam;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class endactivity extends AppCompatActivity {
    private Button button6, button7;
    public static final String EXTRA_MESSAGE = "com.example.wam.MESSAGE";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_endactivity);

        Intent intent = getIntent();
        String message = intent.getStringExtra(M2X3.EXTRA_MESSAGE);
        String message2 = intent.getStringExtra(M3X4.EXTRA_MESSAGE);
        String message3 = intent.getStringExtra(M4X5.EXTRA_MESSAGE);


        // Capture the layout's TextView and set the string as its text
        TextView textView = findViewById(R.id.textView7);
        textView.setText(message);
        TextView textView2 = findViewById(R.id.textView8);
        textView.setText(message2);
        TextView textView3 = findViewById(R.id.textView9);
        textView.setText(message3
        );

        button6 = (Button) findViewById(R.id.button6);
        button7 = (Button) findViewById(R.id.button7);

        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openback();
            }
        });
        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                System.exit(0);
            }
        });


    }

    public void openback() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
    public void quit() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}
