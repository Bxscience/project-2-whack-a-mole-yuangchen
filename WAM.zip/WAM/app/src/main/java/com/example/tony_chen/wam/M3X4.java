package com.example.tony_chen.wam;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Random;

public class M3X4 extends AppCompatActivity {
    private ImageButton mol21, mol22, mol23, mol24, mol25, mol26, mol27, mol28, mol29, mol210, mol211, mol212;
    private int score, mole;
    private CountDownTimer timer;
    private ArrayList<ImageButton> buttons;
    private Random random;
    private TextView timetv, scoretv;
    public static final String EXTRA_MESSAGE = "com.example.wam.MESSAGE";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_m3_x4);

        buttons = new ArrayList<>();
        random = new Random();
        score = 0;
        mole = 0;
        initializeGame();

        timer = new CountDownTimer(60000,1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                timetv.setText("Time: " + millisUntilFinished / 1000);
                buttons.get(mole).setVisibility(View.INVISIBLE);
                mole = random.nextInt(12);
                buttons.get(mole).setVisibility(View.VISIBLE);
            }

            @Override
            public void onFinish() {
                buttons.get(mole).setVisibility(View.INVISIBLE);
                timetv.setText("Time: 0");
                openback();
            }
        }.start();
    }


    private void initializeGame(){
        mol21 = (ImageButton) findViewById(R.id.mol21);
        mol22 = (ImageButton) findViewById(R.id.mol22);
        mol23 = (ImageButton) findViewById(R.id.mol23);
        mol24 = (ImageButton) findViewById(R.id.mol24);
        mol25 = (ImageButton) findViewById(R.id.mol25);
        mol26 = (ImageButton) findViewById(R.id.mol26);
        mol27 = (ImageButton) findViewById(R.id.mol27);
        mol28 = (ImageButton) findViewById(R.id.mol28);
        mol29 = (ImageButton) findViewById(R.id.mol29);
        mol210 = (ImageButton) findViewById(R.id.mol210);
        mol211 = (ImageButton) findViewById(R.id.mol211);
        mol212 = (ImageButton) findViewById(R.id.mol212);

        timetv = (TextView) findViewById(R.id.textView2);
        scoretv = (TextView) findViewById(R.id.textView6);

        buttons.add(mol21);
        buttons.add(mol22);
        buttons.add(mol23);
        buttons.add(mol24);
        buttons.add(mol25);
        buttons.add(mol26);
        buttons.add(mol27);
        buttons.add(mol28);
        buttons.add(mol29);
        buttons.add(mol210);
        buttons.add(mol211);
        buttons.add(mol212);



        for (ImageButton imageButton : buttons){
            imageButton.setOnClickListener(buttonListener);
        }
    }

    private final View.OnClickListener buttonListener = new View.OnClickListener(){

        public void onClick(View v){
            playwhack();
            score += 1;
            scoretv.setText(String.valueOf(score));
            buttons.get(mole).setVisibility(View.INVISIBLE);
        }
    };

    public void openback() {
        Intent intent = new Intent(this, endactivity.class);
        TextView editText = (TextView) findViewById(R.id.textView6);
        String message = editText.getText().toString();
        intent.putExtra(EXTRA_MESSAGE, message);
        startActivity(intent);
    }

    public void playwhack(){
        MediaPlayer player = MediaPlayer.create(getApplicationContext(), R.raw.whack);
        player.start();
    }

}
